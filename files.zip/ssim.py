"""
metrics/ssim.py  –  Per-pixel SSIM map và Weighted-SSIM (WS-SSIM).

Công thức WS-SSIM:
    WS-SSIM = Σ DM(x,y)·SM(x,y) / Σ SM(x,y)

Trong đó:
    DM  = per-pixel SSIM (Distortion Map)
    SM  = saliency map (Saliency Map)
"""

import os
import numpy as np
from scipy.ndimage import uniform_filter

from ..io_utils.saliency import read_saliency_map


# ─── Per-pixel SSIM map ───────────────────────────────────────────────────────

def ssim_map(img1: np.ndarray, img2: np.ndarray,
             win_size: int = 11,
             data_range: float = 255.0,
             k1: float = 0.01,
             k2: float = 0.03) -> np.ndarray:
    """
    Tính per-pixel SSIM map (Distortion Map) giữa 2 ảnh grayscale float64 [H, W].
    Trả về DM [H, W] với giá trị trong [-1, 1].
    """
    C1 = (k1 * data_range) ** 2
    C2 = (k2 * data_range) ** 2

    mu1 = uniform_filter(img1, size=win_size)
    mu2 = uniform_filter(img2, size=win_size)

    mu1_sq  = mu1 * mu1
    mu2_sq  = mu2 * mu2
    mu1_mu2 = mu1 * mu2

    sigma1_sq = uniform_filter(img1 * img1, size=win_size) - mu1_sq
    sigma2_sq = uniform_filter(img2 * img2, size=win_size) - mu2_sq
    sigma12   = uniform_filter(img1 * img2, size=win_size) - mu1_mu2

    numerator   = (2 * mu1_mu2 + C1) * (2 * sigma12   + C2)
    denominator = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)

    return (numerator / (denominator + 1e-10)).astype(np.float32)


# ─── Weighted SSIM ────────────────────────────────────────────────────────────

def calculate_weighted_ssim(raw_path: str, rec_path: str,
                             sal_dir: str,
                             width: int, height: int, frames: int,
                             win_size: int = 11) -> float | None:
    """
    Tính Weighted-SSIM trung bình trên tất cả frame của 1 sequence.

    Parameters
    ----------
    raw_path  : file YUV gốc
    rec_path  : file YUV tái tạo
    sal_dir   : thư mục chứa frame_xxxx_map.bin cho sequence này
    width, height, frames : thông số video
    win_size  : kích thước cửa sổ SSIM (default 11)
    """
    y_size   = width * height
    uv_size  = (width // 2) * (height // 2) * 2
    ws_list  = []

    try:
        with open(raw_path, "rb") as f_raw, open(rec_path, "rb") as f_rec:
            for i in range(frames):
                raw_bytes = f_raw.read(y_size)
                rec_bytes = f_rec.read(y_size)
                if not raw_bytes or not rec_bytes:
                    break

                raw_y = np.frombuffer(raw_bytes, dtype=np.uint8).reshape(height, width).astype(np.float64)
                rec_y = np.frombuffer(rec_bytes, dtype=np.uint8).reshape(height, width).astype(np.float64)

                f_raw.seek(uv_size, 1)
                f_rec.seek(uv_size, 1)

                dm = ssim_map(raw_y, rec_y, win_size=win_size)   # [H, W]

                sal_path = os.path.join(sal_dir, f"frame_{i:04d}_map.bin")
                sm = read_saliency_map(sal_path, width, height)

                if sm is None:
                    ws_list.append(float(dm.mean()))
                    continue

                if sm.shape != (height, width):
                    import cv2
                    sm = cv2.resize(sm, (width, height), interpolation=cv2.INTER_LINEAR)

                sum_sm = np.sum(sm)
                if sum_sm < 1e-10:
                    ws_list.append(float(dm.mean()))
                else:
                    ws_list.append(float(np.sum(dm * sm) / sum_sm))

    except Exception as e:
        print(f"  [Error] WS-SSIM: {e}")
        return None

    return float(np.mean(ws_list)) if ws_list else None
