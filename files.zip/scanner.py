"""
report/scanner.py  –  Quét toàn bộ output và tính metrics.

Trả về DataFrame với các cột:
    Sequence, Method, QP, BPP, PSNR, WS_SSIM_<sal_method>, ...
"""

import os
import re
import pandas as pd

from ..config import (
    INPUT_YUV_DIR, OUTPUT_DIR, SAL_ROOT,
    COMPRESSED_EXT, REGEX_FILENAME, METHODS, SAL_METHODS,
)
from ..io_utils import parse_filename
from ..metrics  import calculate_y_psnr, calculate_bpp, calculate_weighted_ssim


def scan_all_metrics(
    input_dir:  str = INPUT_YUV_DIR,
    output_dir: str = OUTPUT_DIR,
    sal_root:   str = SAL_ROOT,
    methods:    list = METHODS,
    sal_methods: list = SAL_METHODS,
    compressed_ext: str = COMPRESSED_EXT,
) -> pd.DataFrame:
    """
    Duyệt tất cả method → QP → sequence và tính PSNR, BPP, WS-SSIM.

    Để thêm metric mới:
      1. Viết hàm tính trong metrics/
      2. Gọi hàm đó ở đây và append vào record dict.
    """
    # Build map: filename → raw_path
    raw_map: dict[str, str] = {}
    for root, _, files in os.walk(input_dir):
        for f in sorted(files):
            if f.endswith(".yuv"):
                raw_map[f] = os.path.join(root, f)

    records = []

    for method_name in sorted(os.listdir(output_dir)):
        method_dir = os.path.join(output_dir, method_name)
        if not os.path.isdir(method_dir):
            continue
        if methods and method_name not in methods:
            continue

        qp_dirs = sorted(
            [d for d in os.listdir(method_dir)
             if os.path.isdir(os.path.join(method_dir, d))],
            key=lambda x: int(re.search(r"\d+", x).group()) if re.search(r"\d+", x) else 0,
        )

        for qp_name in qp_dirs:
            qp_dir = os.path.join(method_dir, qp_name)

            for filename in sorted(os.listdir(qp_dir)):
                if not filename.endswith(".yuv"):
                    continue
                if filename not in raw_map:
                    print(f"  [Warn] Không có raw: {filename}")
                    continue

                raw_path = raw_map[filename]
                rec_path = os.path.join(qp_dir, filename)
                name_core, w, h, frames = parse_filename(filename, REGEX_FILENAME)
                if w == 0:
                    continue

                # ── Core metrics ────────────────────────────────────────────
                psnr = calculate_y_psnr(raw_path, rec_path, w, h, frames)
                bin_path = os.path.join(qp_dir, filename.replace(".yuv", compressed_ext))
                bpp  = calculate_bpp(bin_path, w, h, frames)

                ws_ssim: dict[str, float | None] = {}
                for sal in sal_methods:
                    sal_dir = os.path.join(sal_root, sal, filename[:-4])
                    ws_ssim[sal] = calculate_weighted_ssim(
                        raw_path, rec_path, sal_dir, w, h, frames
                    )
                # ────────────────────────────────────────────────────────────

                if psnr is None:
                    continue

                record: dict = {
                    "Sequence": name_core,
                    "Method":   method_name,
                    "QP":       qp_name,
                    "BPP":      bpp,
                    "PSNR":     psnr,
                }
                for sal, val in ws_ssim.items():
                    record[f"WS_SSIM_{sal}"] = val

                bpp_s = f"BPP={bpp:.4f}" if bpp is not None else "BPP=N/A"
                ws_s  = "  ".join(
                    f"WS-SSIM({k})={v:.4f}" if v is not None else f"WS-SSIM({k})=N/A"
                    for k, v in ws_ssim.items()
                )
                print(f"  [{method_name} | {qp_name}] {filename}: {bpp_s}  {ws_s}")
                records.append(record)

    return pd.DataFrame(records)
