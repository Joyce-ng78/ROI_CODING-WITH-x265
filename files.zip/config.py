"""
config.py  –  Chỉnh SỬA FILE NÀY KHI:
  - Thêm method mới
  - Đổi experiment (rdo_medium → rdo_fast ...)
  - Thay đổi QP list

Các notebook và script KHÔNG cần sửa khi thêm method.
"""

import os

# ─── ROOT ────────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# ─── EXPERIMENT TAG  (đổi 1 chỗ này là đổi toàn bộ experiment) ─────────────
EXPERIMENT = "rdo_medium"

# ─── PATHS ───────────────────────────────────────────────────────────────────
INPUT_YUV_DIR   = os.path.join(PROJECT_ROOT, "data", "raw_yuv", "class_B")
OUTPUT_DIR      = os.path.join(PROJECT_ROOT, "outputs", f"output_{EXPERIMENT}")
SAL_ROOT        = os.path.join(PROJECT_ROOT, "data", "roi_extraction")
LOG_DIR         = os.path.join(PROJECT_ROOT, "logs", f"logs_{EXPERIMENT}")
RD_CURVE_DIR    = os.path.join(PROJECT_ROOT, "outputs", "rd_curves", f"{EXPERIMENT}_curves")
VIS_DIR         = os.path.join(PROJECT_ROOT, "outputs", "visualize")

# Báo cáo Excel đầu ra
REPORT_METRICS  = os.path.join(LOG_DIR, f"report_{EXPERIMENT}_metrics.xlsx")
REPORT_TIME     = os.path.join(LOG_DIR, f"Overall_time.xlsx")

# ─── METHODS ─────────────────────────────────────────────────────────────────
# Thêm method mới VÀO ĐÂY, toàn bộ pipeline tự nhận.
METHODS = [
    "nonroi_CQP_preset_medium_rdo_1",
    "nonroi_CRF_preset_medium_rdo_6",
    "saliency_max_preset_medium_rdo_6",
    "saliency_mean_preset_medium_rdo_6",
    "saliency_median_preset_medium_rdo_6",
    "yolov5_openvino_preset_medium_rdo_6",
    # ← thêm method mới ở đây
]

# Method dùng làm anchor cho BD-Rate
ANCHOR_METHOD = "nonroi_CQP_preset_medium_rdo_1"

# ─── SALIENCY METHODS (dùng cho WS-SSIM) ─────────────────────────────────────
SAL_METHODS = ["saliency"]

# ─── FORMAT FILE ─────────────────────────────────────────────────────────────
COMPRESSED_EXT  = ".bin"
REGEX_FILENAME  = r"(.+)_(\d+)x(\d+)_(\d+)"

# QP được filter khi visualize (None = lấy tất cả)
ALLOWED_QPS = None   # hoặc {"qp32", "qp35"}
